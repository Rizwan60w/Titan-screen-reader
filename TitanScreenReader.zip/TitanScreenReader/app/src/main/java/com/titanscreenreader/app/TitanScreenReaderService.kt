package com.titanscreenreader.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.titanscreenreader.app.audio.AudioFeedbackManager
import com.titanscreenreader.app.automation.AutoActionEngine
import com.titanscreenreader.app.clipboard.ClipboardManagerEngine
import com.titanscreenreader.app.gestures.AdvancedGestureEngine
import com.titanscreenreader.app.navigation.FocusManager
import com.titanscreenreader.app.notifications.SmartNotificationReader
import com.titanscreenreader.app.ocr.SmartOcrEngine
import com.titanscreenreader.app.sensors.SensorsController
import com.titanscreenreader.app.speech.DualTtsEngine

/**
 * TitanScreenReaderService:
 * जीसीओ (Jieshuo/CSR) और टॉकबैक से भी अधिक उन्नत और फ़ीचर-रिच स्क्रीन रीडर।
 * सभी फ़ीचर्स डिफ़ॉल्ट रूप से एक्टिवेटेड हैं:
 * 1. Dual TTS Engine
 * 2. In-built Procedural Sound Scheme (बिना अलग साउंड फ़ाइल के)
 * 3. Smart Auto-Action & Ad-Skipper
 * 4. On-Device Instant Screen OCR
 * 5. Smart Notification Announcer (WhatsApp, Telegram आदि)
 * 6. Multi-Item Clipboard Stack
 * 7. Shake to read Time & Battery
 * 8. Proximity Silence Sensor
 * 9. 24+ Angle Gestures
 */
class TitanScreenReaderService : AccessibilityService() {

    private lateinit var dualTts: DualTtsEngine
    private lateinit var audioManager: AudioFeedbackManager
    private lateinit var autoActionEngine: AutoActionEngine
    private lateinit var smartOcrEngine: SmartOcrEngine
    private lateinit var notificationReader: SmartNotificationReader
    private lateinit var clipboardEngine: ClipboardManagerEngine
    private lateinit var sensorsController: SensorsController
    private lateinit var focusManager: FocusManager
    private lateinit var gestureEngine: AdvancedGestureEngine
    private lateinit var vibrator: Vibrator

    private var currentFocusedNode: AccessibilityNodeInfo? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pendingSpeechRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()

        dualTts = DualTtsEngine(this)
        audioManager = AudioFeedbackManager()
        autoActionEngine = AutoActionEngine()
        smartOcrEngine = SmartOcrEngine(this)
        clipboardEngine = ClipboardManagerEngine(this)
        focusManager = FocusManager()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        notificationReader = SmartNotificationReader { speechText ->
            dualTts.speakSecondary(speechText, interrupt = false)
        }

        sensorsController = SensorsController(
            context = this,
            onShakeTriggered = { info ->
                audioManager.playSound(AudioFeedbackManager.SoundType.MODE_SWITCH)
                dualTts.speakSecondary(info, interrupt = true)
                vibrate(40)
            },
            onProximityCovered = {
                dualTts.stopAll()
            }
        )
        sensorsController.startListening()

        gestureEngine = AdvancedGestureEngine(
            onNext = { moveFocus(forward = true) },
            onPrevious = { moveFocus(forward = false) },
            onClick = { performClickOnFocusedNode() },
            onLongClick = { performLongClickOnFocusedNode() },
            onGranularityCycle = {
                val nextG = focusManager.cycleGranularityForward()
                audioManager.playSound(AudioFeedbackManager.SoundType.MODE_SWITCH)
                dualTts.speakSecondary("नेविगेशन: ${nextG.name}", interrupt = true)
                vibrate(25)
            },
            onGlobalHome = {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                performGlobalAction(GLOBAL_ACTION_HOME)
            },
            onGlobalBack = {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                performGlobalAction(GLOBAL_ACTION_BACK)
            },
            onGlobalRecents = {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                performGlobalAction(GLOBAL_ACTION_RECENTS)
            },
            onGlobalNotifications = {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            },
            onGlobalQuickSettings = {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            },
            onReadFromTop = { readCurrentWindowFromTop() },
            onTriggerOcr = {
                dualTts.speakSecondary("स्क्रीन ओसीआर स्कैन हो रहा है...", interrupt = true)
                smartOcrEngine.captureAndReadScreen { text ->
                    audioManager.playSound(AudioFeedbackManager.SoundType.OCR_SUCCESS)
                    dualTts.speakContent(text, interrupt = true)
                }
            },
            onOpenClipboard = {
                val clip = clipboardEngine.getLatestClip() ?: "क्लिपबोर्ड खाली है"
                audioManager.playSound(AudioFeedbackManager.SoundType.MODE_SWITCH)
                dualTts.speakSecondary("क्लिपबोर्ड: $clip", interrupt = true)
            },
            onOpenQuickMenu = {
                audioManager.playSound(AudioFeedbackManager.SoundType.MODE_SWITCH)
                dualTts.speakSecondary("टाइटन त्वरित मेनू खोला गया", interrupt = true)
            },
            onToggleMute = {
                dualTts.stopAll()
                vibrate(30)
            }
        )

        audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
        dualTts.speakContent("टाइटन स्क्रीन रीडर सक्रिय है। सभी उन्नत फ़ीचर्स डिफ़ॉल्ट रूप से चालू हैं।", interrupt = true)
        Log.i("TitanScreenReader", "TitanScreenReader successfully started.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED -> {
                val source = event.source ?: return
                currentFocusedNode = source
                audioManager.playSound(AudioFeedbackManager.SoundType.FOCUS)
                debounceSpeak(buildNodeDescription(source))
                vibrate(10)
            }

            AccessibilityEvent.TYPE_VIEW_HOVER_ENTER -> {
                val source = event.source ?: return
                currentFocusedNode = source
                source.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
                audioManager.playSound(AudioFeedbackManager.SoundType.FOCUS)
                debounceSpeak(buildNodeDescription(source))
                vibrate(12)
            }

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                audioManager.playSound(AudioFeedbackManager.SoundType.SCROLL)
            }

            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                notificationReader.handleNotificationEvent(event)
            }

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                audioManager.playSound(AudioFeedbackManager.SoundType.WINDOW_CHANGE)
                val root = rootInActiveWindow
                // ऑटो एक्शन और विज्ञापन स्वतः स्किप करने की जाँच
                autoActionEngine.checkAndPerformAutoActions(root)

                val title = event.contentDescription ?: event.text.joinToString(", ")
                if (title.isNotBlank()) {
                    dualTts.speakContent(title, interrupt = true)
                }
            }
        }
    }

    override fun onGesture(gestureId: Int): Boolean {
        return gestureEngine.handleGesture(gestureId) || super.onGesture(gestureId)
    }

    private fun moveFocus(forward: Boolean) {
        val root = rootInActiveWindow ?: return
        val targetNode = if (forward) {
            focusManager.findNext(root, currentFocusedNode)
        } else {
            focusManager.findPrevious(root, currentFocusedNode)
        }

        targetNode?.let { node ->
            currentFocusedNode = node
            node.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
            audioManager.playSound(AudioFeedbackManager.SoundType.FOCUS)
            dualTts.speakContent(buildNodeDescription(node), interrupt = true)
            vibrate(15)
        } ?: run {
            audioManager.playSound(AudioFeedbackManager.SoundType.EDGE_REACHED)
        }
    }

    private fun performClickOnFocusedNode() {
        currentFocusedNode?.let { node ->
            audioManager.playSound(AudioFeedbackManager.SoundType.CLICK)
            val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (!clicked && node.parent != null) {
                node.parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            vibrate(30)
        }
    }

    private fun performLongClickOnFocusedNode() {
        currentFocusedNode?.let { node ->
            audioManager.playSound(AudioFeedbackManager.SoundType.CLICK)
            node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
            vibrate(50)
        }
    }

    private fun readCurrentWindowFromTop() {
        val root = rootInActiveWindow ?: return
        val sb = StringBuilder("स्क्रीन प्रारंभ से पठन:\n")
        val queue = java.util.LinkedList<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.poll() ?: continue
            val desc = n.text?.toString() ?: n.contentDescription?.toString()
            if (!desc.isNullOrBlank() && n.isVisibleToUser) {
                sb.append(desc).append(". ")
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { queue.add(it) }
            }
        }
        dualTts.speakContent(sb.toString(), interrupt = true)
    }

    private fun debounceSpeak(text: String) {
        pendingSpeechRunnable?.let { handler.removeCallbacks(it) }
        pendingSpeechRunnable = Runnable {
            dualTts.speakContent(text, interrupt = true)
        }
        handler.postDelayed(pendingSpeechRunnable!!, 15)
    }

    private fun buildNodeDescription(node: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        val text = node.text?.toString()?.trim()
        val contentDesc = node.contentDescription?.toString()?.trim()

        when {
            !contentDesc.isNullOrEmpty() -> sb.append(contentDesc)
            !text.isNullOrEmpty() -> sb.append(text)
            else -> {
                val viewId = node.viewIdResourceName
                if (!viewId.isNullOrEmpty()) {
                    val cleanId = viewId.substringAfterLast(":id/").substringAfterLast("/")
                        .replace("btn_", "").replace("ic_", "").replace("_", " ")
                    sb.append(cleanId)
                } else if (node.isClickable) {
                    sb.append("बटन")
                }
            }
        }

        if (node.isCheckable) {
            sb.append(if (node.isChecked) ", चेक किया गया" else ", अनचेक")
        }

        val className = node.className?.toString() ?: ""
        if (className.contains("Button") && !sb.contains("बटन", ignoreCase = true)) {
            sb.append(", बटन")
        } else if (className.contains("EditText")) {
            sb.append(", संपादन बॉक्स")
        } else if (className.contains("Switch")) {
            sb.append(", स्विच")
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && node.isHeading) {
            sb.append(", शीर्षक")
        }

        return sb.toString()
    }

    private fun vibrate(durationMs: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }

    override fun onInterrupt() {
        dualTts.stopAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorsController.stopListening()
        dualTts.shutdown()
    }
}
