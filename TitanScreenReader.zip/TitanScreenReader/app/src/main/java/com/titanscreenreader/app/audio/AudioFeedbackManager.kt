package com.titanscreenreader.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.sin

/**
 * इन-बिल्ट प्रोसीजरल साउंड स्कीम (Procedural Sound Synthesizer):
 * जीशू (CSR) में यूज़र को अलग से भारी साउंड थीम्स डाउनलोड करनी पड़ती हैं।
 * टाइटन स्क्रीन रीडर में हाई-डेफिनिशन साइन-वेव ऑडिबल टोन जनरेटर सीधे कोड से तैयार होता है,
 * जिससे किसी एक्सटर्नल ऑडियो फ़ाइल की आवश्यकता नहीं होती और 0ms लेटेंसी पर तुरंत साउंड प्ले होता है।
 */
class AudioFeedbackManager {

    enum class SoundType {
        FOCUS,          // 440 Hz क्लिक टोन
        CLICK,          // 880 Hz शार्प बीप
        SCROLL,         // 320 Hz सॉफ्ट व्हूश
        WINDOW_CHANGE,  // 660 Hz चाइम
        EDGE_REACHED,   // 220 Hz लो थंप
        MODE_SWITCH,    // 520 Hz डुअल टोन
        OCR_SUCCESS     // 1000 Hz हाई टोन
    }

    var isSoundEnabled: Boolean = true

    fun playSound(type: SoundType) {
        if (!isSoundEnabled) return
        thread(start = true, isDaemon = true) {
            when (type) {
                SoundType.FOCUS -> playTone(587.33, 20)      // D5 नोट, 20ms
                SoundType.CLICK -> playTone(880.0, 30)       // A5 नोट, 30ms
                SoundType.SCROLL -> playTone(440.0, 15)      // A4 नोट, 15ms
                SoundType.WINDOW_CHANGE -> playChord(listOf(523.25, 659.25), 45) // C-E कॉर्ड
                SoundType.EDGE_REACHED -> playTone(220.0, 40) // A3 नोट
                SoundType.MODE_SWITCH -> playTone(783.99, 35) // G5 नोट
                SoundType.OCR_SUCCESS -> playChord(listOf(523.25, 659.25, 783.99), 60) // मेजर ट्रायड
            }
        }
    }

    private fun playTone(freqHz: Double, durationMs: Int) {
        val sampleRate = 44100
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val generatedSnd = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val angle = 2.0 * Math.PI * i / (sampleRate / freqHz)
            // स्मूथ फेड-आउट ताकि कोई 'पॉप' साउंड न आए
            val envelope = (numSamples - i).toDouble() / numSamples
            generatedSnd[i] = (sin(angle) * 32767 * envelope * 0.4).toInt().toShort()
        }

        playRawAudio(generatedSnd, sampleRate)
    }

    private fun playChord(freqs: List<Double>, durationMs: Int) {
        val sampleRate = 44100
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val generatedSnd = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            var sample = 0.0
            for (freq in freqs) {
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                sample += sin(angle)
            }
            sample /= freqs.size
            val envelope = (numSamples - i).toDouble() / numSamples
            generatedSnd[i] = (sample * 32767 * envelope * 0.45).toInt().toShort()
        }

        playRawAudio(generatedSnd, sampleRate)
    }

    private fun playRawAudio(data: ShortArray, sampleRate: Int) {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val track = AudioTrack.Builder()
            .setAudioAttributes(audioAttributes)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(data, 0, data.size)
        track.play()
        // बैकग्राउंड में प्ले समाप्त होने पर रिलीज़
        Thread.sleep(data.size * 1000L / sampleRate + 10)
        track.release()
    }
}
