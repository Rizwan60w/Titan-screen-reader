package com.titanscreenreader.app.automation

import android.view.accessibility.AccessibilityNodeInfo

/**
 * ऑटोमेशन व ऑटो-क्लिकर इंजन (Auto Action & Ad Skipper):
 * डिफ़ॉल्ट रूप से सक्रिय!
 * 1. YouTube और अन्य ऐप्स में "Skip Ad", "विज्ञापन छोड़ें", "Skip", "Close", "Not Now" को अपने आप पहचानकर क्लिक करता है।
 * 2. डायलॉग्स में "Got it", "I Agree", "Allow" को एक टैप या ऑटो-बायपास कर सकता है।
 */
class AutoActionEngine {

    var isAutoSkipAdsEnabled: Boolean = true

    private val adSkipKeywords = listOf(
        "skip ad", "skip ads", "विज्ञापन छोड़ें", "skip", "विज्ञापन छोड़ें", "close ad", "not now"
    )

    /**
     * विंडो लोड होते ही बैकग्राउंड में स्कैन करके ऑटो-क्लिक करता है
     */
    fun checkAndPerformAutoActions(rootNode: AccessibilityNodeInfo?): Boolean {
        if (!isAutoSkipAdsEnabled || rootNode == null) return false
        return scanAndClickTarget(rootNode)
    }

    private fun scanAndClickTarget(node: AccessibilityNodeInfo): Boolean {
        val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim().lowercase()

        if (text.isNotEmpty()) {
            for (kw in adSkipKeywords) {
                if (text == kw || text.startsWith(kw)) {
                    if (node.isClickable) {
                        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    } else if (node.parent?.isClickable == true) {
                        node.parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    }
                }
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (scanAndClickTarget(child)) return true
        }
        return false
    }
}
