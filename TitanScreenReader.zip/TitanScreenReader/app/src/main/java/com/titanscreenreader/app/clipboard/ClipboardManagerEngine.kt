package com.titanscreenreader.app.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import java.util.LinkedList

/**
 * मल्टी-क्लिपबोर्ड व टेक्स्ट ऑपरेशन्स (Advanced Clipboard Manager):
 * 1. क्लिपबोर्ड हिस्ट्री: पिछले 20 कॉपीड आइटम्स को याद रखता है।
 * 2. अपेंड कॉपी (Append Copy): नए टेक्स्ट को बिना पुराने को मिटाए क्लिपबोर्ड में जोड़ता है।
 * 3. टेक्स्ट ट्रांसलेटर / कैरेक्टर काउंटर।
 */
class ClipboardManagerEngine(private val context: Context) {

    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val history = LinkedList<String>()

    fun copyToClipboard(text: String, append: Boolean = false): String {
        val finalContent = if (append && history.isNotEmpty()) {
            "${history.first}\n$text"
        } else {
            text
        }

        val clip = ClipData.newPlainText("TitanCopiedText", finalContent)
        clipboard.setPrimaryClip(clip)

        if (history.contains(finalContent)) {
            history.remove(finalContent)
        }
        history.addFirst(finalContent)
        if (history.size > 20) history.removeLast()

        return if (append) "टेक्स्ट जोड़ा गया और कॉपी हुआ" else "कॉपी किया गया"
    }

    fun getLatestClip(): String? {
        return history.firstOrNull() ?: clipboard.primaryClip?.getItemAt(0)?.text?.toString()
    }

    fun getHistoryList(): List<String> = history.toList()
}
