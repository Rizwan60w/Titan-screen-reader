package com.titanscreenreader.app.navigation

import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import java.util.LinkedList

/**
 * हाई-स्पीड स्पैटियल फ़ोकस मैनेजर (Spatial Focus Engine)
 */
class FocusManager {

    enum class NavigationGranularity {
        DEFAULT,   // सभी इंटरैक्टिव तत्व
        HEADINGS,  // केवल शीर्षक
        CONTROLS,  // बटन, स्विचेस, एडिट टेक्स्ट
        LINKS,     // वेब लिंक्स
        CONTAINERS // लिस्ट्स व कार्ड्स
    }

    var currentGranularity: NavigationGranularity = NavigationGranularity.DEFAULT

    fun findNext(root: AccessibilityNodeInfo?, currentFocus: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val flatList = getFlatInteractiveNodes(root)
        if (flatList.isEmpty()) return null

        val filtered = filterByGranularity(flatList, currentGranularity)
        if (filtered.isEmpty()) return null

        if (currentFocus == null) return filtered.first()
        val index = filtered.indexOfFirst { it == currentFocus }
        return if (index != -1 && index + 1 < filtered.size) filtered[index + 1] else filtered.first()
    }

    fun findPrevious(root: AccessibilityNodeInfo?, currentFocus: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val flatList = getFlatInteractiveNodes(root)
        if (flatList.isEmpty()) return null

        val filtered = filterByGranularity(flatList, currentGranularity)
        if (filtered.isEmpty()) return null

        if (currentFocus == null) return filtered.last()
        val index = filtered.indexOfFirst { it == currentFocus }
        return if (index > 0) filtered[index - 1] else filtered.last()
    }

    fun cycleGranularityForward(): NavigationGranularity {
        val values = NavigationGranularity.values()
        currentGranularity = values[(currentGranularity.ordinal + 1) % values.size]
        return currentGranularity
    }

    private fun getFlatInteractiveNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        val queue = LinkedList<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.poll() ?: continue
            if (!node.isVisibleToUser) continue
            if (isMeaningfulNode(node)) result.add(node)

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }

        val rectA = Rect()
        val rectB = Rect()
        result.sortWith { a, b ->
            a.getBoundsInScreen(rectA)
            b.getBoundsInScreen(rectB)
            if (Math.abs(rectA.top - rectB.top) > 25) {
                rectA.top.compareTo(rectB.top)
            } else {
                rectA.left.compareTo(rectB.left)
            }
        }
        return result
    }

    private fun isMeaningfulNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isCheckable || node.isClickable || node.isFocusable || node.isLongClickable) return true
        if (!node.text.isNullOrBlank()) return true
        if (!node.contentDescription.isNullOrBlank()) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && node.isHeading) return true
        return false
    }

    private fun filterByGranularity(
        list: List<AccessibilityNodeInfo>,
        granularity: NavigationGranularity
    ): List<AccessibilityNodeInfo> {
        return when (granularity) {
            NavigationGranularity.DEFAULT -> list
            NavigationGranularity.HEADINGS -> list.filter {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && it.isHeading) return@filter true
                it.className?.contains("Heading", ignoreCase = true) == true
            }
            NavigationGranularity.CONTROLS -> list.filter {
                it.isClickable || it.isCheckable || it.className?.contains("Button", ignoreCase = true) == true ||
                        it.className?.contains("EditText", ignoreCase = true) == true ||
                        it.className?.contains("Switch", ignoreCase = true) == true
            }
            NavigationGranularity.LINKS -> list.filter {
                it.className?.contains("Link", ignoreCase = true) == true ||
                        it.contentDescription?.contains("http", ignoreCase = true) == true
            }
            NavigationGranularity.CONTAINERS -> list.filter {
                it.className?.contains("RecyclerView", ignoreCase = true) == true ||
                        it.className?.contains("ListView", ignoreCase = true) == true ||
                        it.className?.contains("CardView", ignoreCase = true) == true
            }
        }
    }
}
