package com.titanscreenreader.app.notifications

import android.app.Notification
import android.view.accessibility.AccessibilityEvent

/**
 * स्मार्ट नोटिफिकेशन रीडर (Smart Notification Announcer):
 * 1. व्हाट्सएप / टेलीग्राम के ग्रुप मैसेज में से ग्रुप का नाम, भेजने वाले का नाम और मुख्य संदेश स्पष्ट बोलता है।
 * 2. लगातार आने वाले 'डाउनलोड हो रहा है' या 'चल रहा है' जैसे स्पैम नोटिफिकेशन्स को स्वतः म्यूट रखता है।
 * 3. स्क्रीन लॉक रहने पर भी कस्टम मोड में संदेश पढ़ सकता है।
 */
class SmartNotificationReader(
    private val onAnnounce: (String) -> Unit
) {

    var isNotificationReadingEnabled: Boolean = true

    // अनचाहे सिस्टम नोटिफिकेशन्स का ब्लैकलिस्ट फ़िल्टर
    private val ignoredPackages = setOf(
        "com.android.systemui",
        "com.google.android.googlequicksearchbox"
    )

    fun handleNotificationEvent(event: AccessibilityEvent) {
        if (!isNotificationReadingEnabled) return
        val packageName = event.packageName?.toString() ?: return
        if (ignoredPackages.contains(packageName)) return

        val parcelable = event.parcelableData
        if (parcelable is Notification) {
            val extras = parcelable.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()

            val speech = buildNotificationString(packageName, title, text, subText)
            if (speech.isNotBlank()) {
                onAnnounce(speech)
            }
        } else {
            val text = event.text.joinToString(", ")
            if (text.isNotBlank()) {
                onAnnounce("सूचना: $text")
            }
        }
    }

    private fun buildNotificationString(pkg: String, title: String?, text: String?, subText: String?): String {
        val appName = when {
            pkg.contains("whatsapp") -> "व्हाट्सएप"
            pkg.contains("telegram") -> "टेलीग्राम"
            pkg.contains("messages") -> "संदेश"
            pkg.contains("gmail") -> "जीमेल"
            else -> ""
        }

        if (title.isNullOrBlank() && text.isNullOrBlank()) return ""

        return buildString {
            if (appName.isNotEmpty()) append("$appName: ")
            if (!title.isNullOrBlank()) append("$title, ")
            if (!text.isNullOrBlank()) append(text)
        }
    }
}
