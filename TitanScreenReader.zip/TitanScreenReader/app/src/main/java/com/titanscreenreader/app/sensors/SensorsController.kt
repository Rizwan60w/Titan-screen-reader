package com.titanscreenreader.app.sensors

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/**
 * मोशन व सेंसर कंट्रोलर (Sensors & Gestures):
 * 1. शेक जेस्चर (Shake to Announce): फ़ोन हिलाने पर तुरंत वर्तमान समय और बैटरी प्रतिशत बोलता है।
 * 2. प्रॉक्सिमिटी सेंसर (Proximity Silence): स्क्रीन पर हाथ फेरने या कान के पास ले जाने पर बोलना तत्काल रुक जाता है।
 */
class SensorsController(
    private val context: Context,
    private val onShakeTriggered: (String) -> Unit,
    private val onProximityCovered: () -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var proximity: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

    private var lastShakeTime: Long = 0
    private var lastAcceleration = 0f
    private var currentAcceleration = SensorManager.GRAVITY_EARTH

    fun startListening() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        proximity?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stopListening() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                lastAcceleration = currentAcceleration
                currentAcceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                val delta = currentAcceleration - lastAcceleration

                if (delta > 11f) { // शेक डिटेक्ट
                    val now = System.currentTimeMillis()
                    if (now - lastShakeTime > 2000) {
                        lastShakeTime = now
                        val info = getSystemTimeAndBattery()
                        onShakeTriggered(info)
                    }
                }
            }

            Sensor.TYPE_PROXIMITY -> {
                val distance = event.values[0]
                val maxRange = event.sensor.maximumRange
                if (distance < maxRange) {
                    onProximityCovered()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun getSystemTimeAndBattery(): String {
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val currentTime = timeFormat.format(Date())

        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = (level * 100 / scale.toFloat()).toInt()

        return "समय: $currentTime, बैटरी: $batteryPct प्रतिशत"
    }
}
