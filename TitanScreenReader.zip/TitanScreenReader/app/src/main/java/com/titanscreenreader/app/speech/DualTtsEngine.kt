package com.titanscreenreader.app.speech

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * डुअल टीटीएस इंजन (Dual TTS Engine Architecture):
 * 1. Primary Engine: मुख्य कंटेंट, वेब टेक्स्ट और नोड विवरण पढ़ने के लिए।
 * 2. Secondary Engine: नोटिफिकेशन, सिस्टम अलर्ट, समय, बैटरी और नोड रोल्स (बटन/चेकबॉक्स) के लिए।
 * दोनों इंजन समानांतर काम करते हैं ताकि मुख्य रीडिंग कभी बाधित न हो।
 */
class DualTtsEngine(private val context: Context) {

    private var primaryTts: TextToSpeech? = null
    private var secondaryTts: TextToSpeech? = null

    private var isPrimaryReady = false
    private var isSecondaryReady = false

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    var speechRate: Float = 1.4f
        set(value) {
            field = value
            primaryTts?.setSpeechRate(value)
            secondaryTts?.setSpeechRate(value * 1.1f)
        }

    var pitch: Float = 1.0f
        set(value) {
            field = value
            primaryTts?.setPitch(value)
            secondaryTts?.setPitch(value * 1.15f) // सेकेंडरी वॉइस थोड़ी अलग पिच पर
        }

    init {
        // प्राइमरी टीटीएस इनिशियलाइज़ेशन
        primaryTts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                primaryTts?.let {
                    it.language = Locale.getDefault()
                    it.setSpeechRate(speechRate)
                    it.setPitch(pitch)
                    isPrimaryReady = true
                }
            }
        }

        // सेकेंडरी टीटीएस इनिशियलाइज़ेशन (विशिष्ट संकेतों के लिए)
        secondaryTts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                secondaryTts?.let {
                    it.language = Locale.getDefault()
                    it.setSpeechRate(speechRate * 1.1f)
                    it.setPitch(pitch * 1.15f)
                    isSecondaryReady = true
                }
            }
        }
    }

    /**
     * मुख्य कंटेंट का तात्कालिक उच्चारण (Zero-latency interrupt)
     */
    fun speakContent(text: CharSequence?, interrupt: Boolean = true) {
        if (!isPrimaryReady || text.isNullOrBlank()) return
        requestAudioFocus()
        val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        primaryTts?.speak(text.toString().trim(), queueMode, params, "Titan_Primary_${System.currentTimeMillis()}")
    }

    /**
     * सेकेंडरी आवाज़ (नोटिफिकेशन, अलर्ट, टाइम, सिस्टम प्रॉम्प्ट्स)
     */
    fun speakSecondary(text: CharSequence?, interrupt: Boolean = false) {
        if (!isSecondaryReady || text.isNullOrBlank()) {
            // फ़ॉलबैक यदि सेकेंडरी तैयार न हो
            speakContent(text, interrupt)
            return
        }
        val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.9f)
        }
        secondaryTts?.speak(text.toString().trim(), queueMode, params, "Titan_Secondary_${System.currentTimeMillis()}")
    }

    fun stopAll() {
        primaryTts?.stop()
        secondaryTts?.stop()
        abandonAudioFocus()
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (audioFocusRequest == null) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(false)
                    .build()
            }
            audioFocusRequest?.let { audioManager.requestAudioFocus(it) }
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        }
    }

    fun shutdown() {
        primaryTts?.shutdown()
        secondaryTts?.shutdown()
    }
}
