package com.titanscreenreader.app.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scrollView = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "टाइटन स्क्रीन रीडर (Titan Screen Reader)"
            textSize = 22f
            setPadding(0, 0, 0, 16)
        }

        val subtitle = TextView(this).apply {
            text = "जीसीओ (Jieshuo/CSR) और टॉकबैक से भी अधिक उन्नत स्क्रीन रीडर।\n\nसब कुछ डिफ़ॉल्ट रूप से एक्टिवेटेड है: कोई अतिरिक्त फ़ाइल या प्लगइन डाउनलोड करने की आवश्यकता नहीं है।"
            textSize = 15f
            setPadding(0, 0, 0, 32)
        }

        val featuresList = TextView(this).apply {
            text = """
★ डिफ़ॉल्ट रूप से सक्रिय सुविधाएँ (Default Active Features):
1. डुअल टीटीएस इंजन (Dual TTS Engines) - मुख्य और सिस्टम आवाज़ अलग।
2. इन-बिल्ट प्रोसीजरल साउंड स्कीम (Zero-delay sound scheme) - बिना किसी अतिरिक्त डाउनलोड के।
3. ऑटो विज्ञापन व डायलॉग स्किप (Auto Ad Skipper & Auto-Clicker)।
4. ऑन-डिवाइस स्क्रीन ओसीआर (Screen OCR for images/games)।
5. स्मार्ट नोटिफिकेशन रीडर (WhatsApp/Telegram प्रेषक व संदेश घोषणा)।
6. मोशन जेस्चर: फ़ोन हिलाने पर समय व बैटरी घोषणा (Shake for Time/Battery)।
7. प्रॉक्सिमिटी साइलेंस: कान या हाथ लगाने पर तुरंत म्यूट।
8. मल्टी-आइटम क्लिपबोर्ड हिस्ट्री व अपेंड कॉपी।
9. 24+ एंगल जेस्चर्स (Angle Gestures)।
            """.trimIndent()
            textSize = 14f
            setPadding(0, 0, 0, 40)
        }

        val btnOpenAccessibility = Button(this).apply {
            text = "एक्सेसिबिलिटी सेटिंग्स में टाइटन चालू करें"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnOpenTts = Button(this).apply {
            text = "टीटीएस (TTS) सेटिंग्स खोलें"
            setOnClickListener {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(featuresList)
        layout.addView(btnOpenAccessibility)
        layout.addView(btnOpenTts)

        scrollView.addView(layout)
        setContentView(scrollView)
    }
}
